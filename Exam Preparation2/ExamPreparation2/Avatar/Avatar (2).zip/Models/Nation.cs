﻿namespace Avatar.Models
{
    public class Nation
    {

    }
}