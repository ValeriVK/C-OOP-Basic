﻿using System.Text;

public abstract class Bender
{
    public Bender(string name, int power)
    {
        this.Name = name;
        this.Power = power;
    }

    protected string Name { get; set; }
    protected int Power { get; set; }
    public double TotalPower { get; set; }
    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"{this.Name}, Power: {this.Power}");
        return sb.ToString().Trim();
    }
}
