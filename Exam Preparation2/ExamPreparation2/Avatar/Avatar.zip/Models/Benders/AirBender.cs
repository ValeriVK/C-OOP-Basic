﻿using System.Text;

public class AirBender : Bender
{
    public AirBender(string name, int power, double aerialIntegrity) : base(name, power)
    {
        
        this.AerialIntegrity = aerialIntegrity;

        this.TotalPower = this.AerialIntegrity * this.Power;
    }
    private double AerialIntegrity { get; set; }
    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.AppendLine($"###Air Bender: {base.ToString()}, Aerial Integrity: {this.AerialIntegrity:f2}");
        
        return sb.ToString().Trim();
    }
}//###Air Bender: Yu, Power: 100, Aerial Integrity: 215.68