﻿using System.Collections.Generic;
public class BenderFactory
{
    public static Bender GetBender(List<string> benderArgs)
    {
        var benderType = benderArgs[0];
        switch (benderType)
        {
            case "Air":
                {
                    var name = benderArgs[1];
                    var power = int.Parse(benderArgs[2]);
                    var aerialIntegrity = double.Parse(benderArgs[3]);
                    return new AirBender(name, power, aerialIntegrity);
                }
                
            case "Water":
                {
                    var name = benderArgs[1];
                    var power = int.Parse(benderArgs[2]);
                    var aerialIntegrity = double.Parse(benderArgs[3]);
                    return new WaterBender(name, power, aerialIntegrity);
                }
                
            case "Fire":
            {
                var name = benderArgs[1];
                var power = int.Parse(benderArgs[2]);
                var aerialIntegrity = double.Parse(benderArgs[3]);
                return new FireBender(name, power, aerialIntegrity);
            }
                
            case "Earth":
            {
                var name = benderArgs[1];
                var power = int.Parse(benderArgs[2]);
                var aerialIntegrity = double.Parse(benderArgs[3]);
                return new EarthBender(name, power, aerialIntegrity);
            }
        }
        return null;
    }
}