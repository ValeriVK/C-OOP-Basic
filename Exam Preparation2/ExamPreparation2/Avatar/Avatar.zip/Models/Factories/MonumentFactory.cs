﻿using System.Collections.Generic;

public class MonumentFactory
    {
        public static Monument GetMonument(List<string> monumentArgs)
        {
            var benderType = monumentArgs[0];
            switch (benderType)
            {
                case "Air":
                {
                    var name = monumentArgs[1];
                    var airAffinity = int.Parse(monumentArgs[2]);
                    return new AirMonument(name, airAffinity);
                }

                case "Water":
                {
                    var name = monumentArgs[1];
                    var waterAffinity = int.Parse(monumentArgs[2]);
                    return new WaterMonument(name, waterAffinity);
                }

                case "Fire":
                {
                    var name = monumentArgs[1];
                    var fireAffinity = int.Parse(monumentArgs[2]);
                    return new FireMonument(name, fireAffinity);
                }

                case "Earth":
                {
                    var name = monumentArgs[1];
                    var earthAffinity = int.Parse(monumentArgs[2]);
                    return new EarthMonument(name, earthAffinity);
                }
            }
            return null;
        }
}