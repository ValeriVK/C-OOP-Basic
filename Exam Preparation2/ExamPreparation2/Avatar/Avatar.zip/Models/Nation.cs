﻿public class Nation
{

}