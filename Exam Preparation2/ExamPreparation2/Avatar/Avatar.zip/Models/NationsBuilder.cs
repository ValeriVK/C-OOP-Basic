﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

public class NationsBuilder
{
    public NationsBuilder()
    {
        this.AirNation = new List<Bender>();
        this.WaterNation = new List<Bender>();
        this.FireNation = new List<Bender>();
        this.EarthNation = new List<Bender>();
        this.AirNationMonuments = new List<Monument>();
        this.WaterNationMonuments = new List<Monument>();
        this.FireNationMonuments = new List<Monument>();
        this.EarthNationMonuments = new List<Monument>();
        this.Wars = new List<string>();
    }

    public List<Bender> AirNation { get; set; }
    public List<Bender> WaterNation { get; set; }
    public List<Bender> FireNation { get; set; }
    public List<Bender> EarthNation { get; set; }
    public List<Monument> AirNationMonuments { get; set; }
    public List<Monument> WaterNationMonuments { get; set; }
    public List<Monument> FireNationMonuments { get; set; }
    public List<Monument> EarthNationMonuments { get; set; }
    public List<string> Wars { get; set; }

    public void AssignBender(List<string> benderArgs)
    {
        var benderType = benderArgs[0];
        var bender = BenderFactory.GetBender(benderArgs);

        switch (benderType)
        {
            case "Air":
                {
                    AirNation.Add(bender);
                }
                break;
            case "Water":
                {
                    WaterNation.Add(bender);
                }
                break;
            case "Fire":
                {
                    FireNation.Add(bender);
                }
                break;
            case "Earth":
                {
                    EarthNation.Add(bender);
                }
                break;
        }

    }
    public void AssignMonument(List<string> monumentArgs)
    {
        var monumentType = monumentArgs[0];
        var monument = MonumentFactory.GetMonument(monumentArgs);
        switch (monumentType)
        {
            case "Air":
                {
                    AirNationMonuments.Add(monument);
                }
                break;
            case "Water":
                {
                    WaterNationMonuments.Add(monument);
                }
                break;
            case "Fire":
                {
                    FireNationMonuments.Add(monument);
                }
                break;
            case "Earth":
                {
                    EarthNationMonuments.Add(monument);
                }
                break;
        }
    }
    public string GetStatus(string nationsType)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"{nationsType} Nation");
        sb.Append("Benders:");
        switch (nationsType)
        {
            case "Air":
                {
                    if (AirNation.Count > 0)
                    {
                        AirNation.ForEach(b => sb.AppendLine(b.ToString()));

                    }
                    else
                    {
                        
                        sb.Append(" None");
                        sb.Append(Environment.NewLine);
                    }
                    if (AirNationMonuments.Count == 0)
                    {
                        sb.AppendLine("Monuments: None");
                    }
                    else
                    {
                        sb.AppendLine("Monuments:");
                        AirNationMonuments.ForEach(m => sb.AppendLine(m.ToString()));
                    }

                }
                break;
            case "Water":
                {
                    if (WaterNation.Count > 0)
                    {
                        WaterNation.ForEach(b => sb.AppendLine(b.ToString()));
                    }
                    else
                    {
                        sb.Append(" None");
                        sb.Append(Environment.NewLine);
                    }

                    if (WaterNationMonuments.Count == 0)
                    {
                        sb.AppendLine("Monuments: None");
                    }
                    else
                    {
                        sb.AppendLine("Monuments:");
                        WaterNationMonuments.ForEach(m => sb.AppendLine(m.ToString()));
                    }
                }
                break;
            case "Fire":
                {
                    if (FireNation.Count > 0)
                    {
                        FireNation.ForEach(b => sb.AppendLine(b.ToString()));
                    }
                    else
                    {
                        sb.Append(" None");
                        sb.Append(Environment.NewLine);
                    }

                    if (FireNationMonuments.Count == 0)
                    {
                        sb.AppendLine("Monuments: None");
                    }
                    else
                    {
                        sb.AppendLine("Monuments:");
                        FireNationMonuments.ForEach(m => sb.AppendLine(m.ToString()));
                    }
                }
                break;
            case "Earth":
                {
                    if (EarthNation.Count > 0)
                    {
                        EarthNation.ForEach(b => sb.AppendLine(b.ToString()));
                    }
                    else
                    {
                        sb.Append(" None");
                        sb.Append(Environment.NewLine);
                    }

                    if (EarthNationMonuments.Count == 0)
                    {
                        sb.AppendLine("Monuments: None");
                    }
                    else
                    {
                        sb.AppendLine("Monuments:");
                        EarthNationMonuments.ForEach(m => sb.AppendLine(m.ToString()));
                    }
                }
                break;
        }
        return sb.ToString().Trim();
    }
    public void IssueWar(string nationsType)
    {
        Wars.Add(nationsType);
        var airNationPower = this.AirNation.Sum(b => b.TotalPower);
        var airMonumentsPower = AirNationMonuments.Sum(m => m.Affinity);
        var TAP = airNationPower + airNationPower * airMonumentsPower / 100;

        var waterNationPower = this.WaterNation.Sum(b => b.TotalPower);
        var waterMonumentsPower = WaterNationMonuments.Sum(m => m.Affinity);
        var TWP = waterNationPower + waterNationPower * waterMonumentsPower / 100;

        var fireNationPower = this.FireNation.Sum(b => b.TotalPower);
        var fireMonumentsPower = FireNationMonuments.Sum(m => m.Affinity);
        var TFP = fireNationPower + fireNationPower * fireMonumentsPower / 100;

        var earthNationPower = this.EarthNation.Sum(b => b.TotalPower);
        var earthMonumentsPower = EarthNationMonuments.Sum(m => m.Affinity);
        var TEP = earthNationPower + earthNationPower * earthMonumentsPower / 100;

        if (TAP > TWP && TAP > TFP && TAP > TEP)
        {
            WaterNation.Clear();
            WaterNationMonuments.Clear();
            FireNation.Clear();
            FireNationMonuments.Clear();
            EarthNation.Clear();
            EarthNationMonuments.Clear();
        }
        else if (TAP < TWP && TWP > TFP && TWP > TEP)
        {
            AirNation.Clear();
            AirNationMonuments.Clear();
            FireNation.Clear();
            FireNationMonuments.Clear();
            EarthNation.Clear();
            EarthNationMonuments.Clear();
        }
        else if (TFP > TAP && TFP > TWP && TFP > TEP)
        {
            AirNation.Clear();
            AirNationMonuments.Clear();
            WaterNation.Clear();
            WaterNationMonuments.Clear();
            EarthNation.Clear();
            EarthNationMonuments.Clear();

        }
        else if (TEP > TAP && TEP > TWP && TEP > TFP)
        {
            AirNation.Clear();
            AirNationMonuments.Clear();
            WaterNation.Clear();
            WaterNationMonuments.Clear();
            FireNation.Clear();
            FireNationMonuments.Clear();

        }

    }
    public string GetWarsRecord()
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= Wars.Count; i++)
        {
            sb.AppendLine($"War {i} issued by {Wars[i - 1]}");
        }
        return sb.ToString().Trim();
    }

}