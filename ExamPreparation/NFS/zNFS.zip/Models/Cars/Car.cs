﻿public abstract class Car
{

}