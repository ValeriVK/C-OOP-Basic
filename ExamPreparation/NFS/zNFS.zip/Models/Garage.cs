﻿public class Garage
{

}