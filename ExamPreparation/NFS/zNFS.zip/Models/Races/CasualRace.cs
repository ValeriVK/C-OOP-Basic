﻿public class CasualRace : Race
{

}