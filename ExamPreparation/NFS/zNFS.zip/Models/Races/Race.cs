﻿public abstract class Race
{

}