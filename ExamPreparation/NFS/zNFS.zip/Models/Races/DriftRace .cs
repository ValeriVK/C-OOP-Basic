﻿public class DriftRace : Race
{

}