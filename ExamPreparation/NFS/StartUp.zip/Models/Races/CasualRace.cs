﻿using System.Collections.Generic;
using System.Runtime.InteropServices;

public class CasualRace : Race
{
    public CasualRace(int length, string route, int prizePool)
               : base(length, route, prizePool)
    {
    }
    //OP
    //(horsepower / acceleration) + (suspension + durability)
    
}